#ifndef __KEY_BOARD_CONTROL_H
#define __KEY_BOARD_CONTROL_H

void Init_Keyboard();
void Close_Keyboard();
int Keyboard_Hit();
int Read_Character();

#endif	
