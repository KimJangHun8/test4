#ifndef _DEBUG_H
#define _DEBUG_H



void Print_Debug();

#endif
