#ifndef __MAIN_H
#define __MAIN_H


int Set_Font_Style();





#endif
